﻿# Prep
Set-ExecutionPolicy Unrestricted -Force
$loggerPath = "C:\Scripts\fix_log4j\Logger.ps1"
. $loggerPath; 
$LogPath = "C:\Scripts\fix_log4j\log.txt"

Write-Log -Level Info -Path $LogPath  -Message "Starting"
#Check if 7zip exist


try{
    if (Test-Path "C:\Program Files\7-Zip\7z.exe"){
        Write-Log -Level Info -Path $LogPath  -Message "7-zip already installed"
    } else {
        Write-Output "Installing 7zip"
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $dlurl = 'https://7-zip.org/' + (Invoke-WebRequest -UseBasicParsing -Uri 'https://7-zip.org/' | Select-Object -ExpandProperty Links | Where-Object {($_.outerHTML -match 'Download')-and ($_.href -like "a/*") -and ($_.href -like "*-x64.exe")} | Select-Object -First 1 | Select-Object -ExpandProperty href)        
        $installerPath = Join-Path $env:TEMP (Split-Path $dlurl -Leaf)
        Invoke-WebRequest $dlurl -OutFile $installerPath
        Start-Process -FilePath $installerPath -Args "/S" -Verb RunAs -Wait
        Remove-Item $installerPath
        Write-Log -Level Info -Path $LogPath  -Message "7-zip installed"
    }

    # Connectors
    try {
        Write-Log -Level Info -Path $LogPath  -Message "creating a backup for connectors"
        
        Copy-Item -Path "C:\Program Files\Sisense\DataConnectors\JVMContainer" -Destination "C:\Program Files\Sisense\DataConnectors\JVMContainerBK" –Recurse
        Write-Log -Level Info -Path $LogPath  -Message "start cleaning Connectors"
        Stop-Service -Name Sisense.JVMConnectorsContainer
        Get-ChildItem -Path "C:\Program Files\Sisense\DataConnectors\JVMContainer" -Filter "*.jar" -Recurse -ErrorAction SilentlyContinue -Force | Foreach-Object {&"C:\Program Files\7-Zip\7z.exe" d $_.FullName org\apache\logging\log4j\core\lookup\JndiLookup.class }
        Start-Service  -Name Sisense.JVMConnectorsContainer
        
        Write-Log -Level Info -Path $LogPath  -Message "Completed. please review the logs and make sure there are no ERRORs, if not connectors are clean"

    } catch {
        Write-Log -Level Error -Path $LogPath ("Error while handeling connectors")
    }

    # Shipper
    try {
        Write-Log -Level Info -Path $LogPath  -Message  "creating backup for shipper"
        
        Stop-Service -Name Sisense.Shipper        
        Copy-Item -Path "C:\Program Files\Sisense\infra\Data\Shipper" -Destination "C:\Program Files\Sisense\infra\Data\ShipperBK"  –Recurse
        Write-Log -Level Info -Path $LogPath  -Message  "start cleanning shipper"
        Get-ChildItem -Path "C:\Program Files\Sisense\infra\Data\Shipper" -Filter "*.jar" -Recurse -ErrorAction SilentlyContinue -Force | Foreach-Object { &"C:\Program Files\7-Zip\7z.exe" d $_.FullName org\apache\logging\log4j\core\lookup\JndiLookup.class }
        Start-Service -Name Sisense.Shipper

        Write-Log -Level Info -Path $LogPath  -Message "Completed. please review the logs and make sure there are no ERRORs, if not shipper are clean"
    } catch {
        Write-Log -Level Error -Path $LogPath ("Error while handeling shipper")
    }
} catch{
    Write-Log -Level Error -Path $LogPath ("Error Installing 7-zip")
    Write-Log -Level Error -Path $LogPath ("Script stopped")
}