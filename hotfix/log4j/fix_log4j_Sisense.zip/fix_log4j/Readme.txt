This patch will fix Sisense log4j vulnerability in Connectors and Shipper
This fix applyies only for native out of the box Sisense windows

1. Extract the zip file into C:\Scripts\ the stracture should be once unzipped C:\Scripts\fix_log4j
2. Run as Admin the PowerShell file C:\Scripts\fix_log4j\fixLog4jSisense.ps1
3. Review the logs under C:\Scripts\fix_log4j\log.txt and make sure there are no errors, in case there are ERRORs please consult with Sisense supportS
4. You are protected