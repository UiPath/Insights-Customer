$uifrostPath = "${Env:ProgramFiles}\Sisense\DataConnectors\JVMContainer\Connectors\UiFrost"



function CopyConnectorJar
{
    try
    {
        Write-Output "Copying .jar"
        Copy-Item com.sisense.connectors.jdbc.UiFrost.jar -Destination "$uifrostPath\com.sisense.connectors.jdbc.UiFrost.jar" -Recurse -force -errorAction stop
    }
    catch
    {
        Write-Output $_.Exception.Message
        exit 1
    }
}

function RestartJVMConnectorSvc
{
    try
    {
        Write-Output "Restarting Sisense.JVMConnectorsContainer Service"
        Restart-Service -Name Sisense.JVMConnectorsContainer -Force -ErrorAction Stop
    }
    catch
    {
        Write-Output "Error restarting Sisense.JVMConnectorsContainer service"
        exit 1
    }

    Write-Output "Restarted Sisense.JVMConnectorsContainer Service"
}

CopyConnectorJar
RestartJVMConnectorSvc


Write-Output "Hotfix applied"
