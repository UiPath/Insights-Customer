
$uifrostPath = "${Env:ProgramFiles}\Sisense\DataConnectors\JVMContainer\Connectors\UiFrost"



function CopyConnectorJar
{
    try
    {
        Write-Output "Copying .jar"
        Copy-Item com.sisense.connectors.jdbc.UiFrost.jar -Destination "$uifrostPath\com.sisense.connectors.jdbc.UiFrost.jar" -Recurse -force -errorAction stop
    }
    catch
    {
        Write-Output $_.Exception.Message
        exit 1
    }
}

function CopyDescriptionJson
{
    try
    {
        Write-Output "Copying description.json"
        Copy-Item description.json -Destination "$uifrostPath\description.json" -Recurse -force -errorAction stop
    }
    catch
    {
        Write-Output $_.Exception.Message
        exit 1
    }
}


function ChangeConnectorProperties
{
    try
    {
        Write-Output "Sync properties file"

        $fileName = "$uifrostPath\uipath_insights.properties"
        $tempFile = "$uifrostPath\uipath_insights-temp.properties"
        
        (Get-Content -Path $fileName -Force -ErrorAction Stop) | Where-Object { $_ -notlike 'insights.dbpassword.encrypted*' } |Set-Content -Path $tempFile -Force -ErrorAction Stop
        Remove-Item $fileName -Force -ErrorAction Stop
        Rename-Item -Path $tempFile -NewName $fileName -Force -ErrorAction Stop
    }
    catch
    {
        Write-Output $_.Exception.Message
        exit 1
    }
}

function RestartJVMConnectorSvc
{
    try
    {
        Write-Output "Restarting Sisense.JVMConnectorsContainer Service"
        Restart-Service -Name Sisense.JVMConnectorsContainer -Force -ErrorAction Stop
    }
    catch
    {
        Write-Output "Error restarting Sisense.JVMConnectorsContainer service"
        exit 1
    }

    Write-Output "Restarted Sisense.JVMConnectorsContainer Service"
}

CopyConnectorJar
CopyDescriptionJson
ChangeConnectorProperties
RestartJVMConnectorSvc


Write-Output "Hotfix applied"



