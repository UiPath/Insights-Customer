#!/bin/bash


SCRIPTDIR=$(dirname "$0") 
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi
source $MODULESPATH/systemUtils/systemUtils.sh
source $MODULESPATH/kubectlUtils/kubectlUtils.sh

setupARGOCD () {
    if [[ -n "$ARGO_CMD" && -n $ARGO_PASSWORD && -n "$ARGO_URL" ]]; then
        return
    fi
    echo "Setting up ArgoCD"
    findAndSetArgoCDBinary
    lookupAndSetArgoCDURL
    lookupandSetArgoCDPassword
    loginToArgoCD

    echo "ArgoCD setup complete"
}

findAndSetArgoCDBinary() {
    echo "Finding ArgoCD binary" >&2
    local cmd="find /opt/UiPathAutomationSuite -type f -name argocd -print0 | xargs -0 ls -t | head -n 1"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to find argocd binary" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi

    # Makes sure we found a binar
    if [ -z "$CMD_OUT" ]; then
        echo "Failed to find argocd binary" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    echo "ArgoCD binary found at $CMD_OUT"
    ARGO_CMD=$CMD_OUT
}

lookupAndSetArgoCDURL () {
    echo "Getting ArgoCD URL" >&2
    set_exit_behavior 0
    kubectlCmd "-n istio-system get virtualservices argocdserver-vs -o jsonpath='{.spec.hosts[0]}'"

    #
    #   Since kubctlCmd has error checking, we log no message for errors.
    #
    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        set_exit_behavior 1
        echo "Old lookup failed, try argocd namespace" >&2
        kubectlCmd "-n argocd  get virtualservices argocd-vs  -o jsonpath='{.spec.hosts[0]}'"
        if [ "$CMD_EXIT_CODE" -ne 0 ]; then
            exit_or_return
            return 1
        fi
    fi

    ARGO_URL=$CMD_OUT
    echo ""
}

lookupandSetArgoCDPassword () {
    echo "Getting ArgoCD password" >&2
    kubectlCmd " get secrets/argocd-admin-password -n argocd -o \"jsonpath={.data['password']}\""

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        exit_or_return
        return 1
    fi
    # base64 decode the password
    local cmd="echo $CMD_OUT | base64 --decode"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to decode argocd password" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi

    echo "Successfully Fetched Password" >&2
    ARGO_PASSWORD=$CMD_OUT
    echo ""
} 

loginToArgoCD () {
    local cmd="$ARGO_CMD login $ARGO_URL --username admin --password $ARGO_PASSWORD --insecure"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to login to argocd" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}

argoCDSetValue () {
    local app=$1
    local key=$2
    local value=$3
    local cmd="$ARGO_CMD app set $app --values $key=$value"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to set $key to $value" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}

argocdDisableSync () {
    local app=$1
    local cmd="$ARGO_CMD app set $app --sync-policy none"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to disable sync for $app" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}

argocdEnableSync () {
    local app=$1
    local cmd="$ARGO_CMD app set $app --sync-policy auto"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to enable sync for $app" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}

#
#   Initialization Command
#
setupARGOCD