#!/bin/bash


SCRIPTDIR=$(dirname "$0")
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

source $MODULESPATH/systemUtils/systemUtils.sh

#
# Source KUBECTL
#
export PATH="$PATH:/usr/local/bin:/var/lib/rancher/rke2/bin"
export KUBECONFIG="/etc/rancher/rke2/rke2.yaml"


createPod () {
    local podName=$1
    local podYaml=$2

    local cmd="kubectl create -f $podYaml"
    execute_command "$cmd"
}

copyIntoPod () {
    local podName=$1
    local sourceFile=$2
    local destinationFile=$3

    local cmd="kubectl cp $sourceFile $podName:$destinationFile"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to copy file $sourceFile to pod $podName" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}

getsfUtilsImage () {
    local cmd="kubectl -n uipath-infra get cronjobs fluentd-logs-cleanup  -o jsonpath='{.spec.jobTemplate.spec.template.spec.containers[0].image}'"
    execute_command "$cmd"
    
    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to get sf utils image" >&2
        echo "ERROR: $CMD_ERR" >&2
        echo "Try manually running the following command: $cmd" >&2
        exit_or_return
        return 1
    fi
}

kubectlCmd () {
    local cmd="kubectl $1"
    execute_command "$cmd"

    if [ "$CMD_EXIT_CODE" -ne 0 ]; then
        echo "Failed to execute kubectl command: $cmd" >&2
        echo "ERROR: $CMD_ERR" >&2
        exit_or_return
        return 1
    fi
}