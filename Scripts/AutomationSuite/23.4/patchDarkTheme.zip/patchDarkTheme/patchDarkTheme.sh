#!/bin/bash

SCRIPTDIR=$(dirname "$0") 
if [ -d "$SCRIPTDIR/../../Modules/" ]; then
    MODULESPATH="$SCRIPTDIR/../../Modules"
else
    MODULESPATH="$SCRIPTDIR/Modules/"
fi

source $MODULESPATH/systemUtils/systemUtils.sh
source $MODULESPATH/kubectlUtils/kubectlUtils.sh
source $MODULESPATH/argocdUtils/argocdUtils.sh

# check if this is ran with sudo or not
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root or with sudo" >&2
    exit 1
fi

# Set the flags to zero
SETUP=0
DISABLE=0
PATCH=0

# Check the inputs
# The flags are --setup, --disable and --patch
parseArgs () {
    case "$1" in
        --setup)
            SETUP=1
            ;;
        --disable)
            DISABLE=1
            ;;
        --patch)
            PATCH=1
            ;;
        *)
            echo "Invalid argument: $1" >&2
            echo "Usage: ./patchDarkTheme.sh --setup|--disable|--patch" >&2
            exit 1
            ;;
    esac
}

# Make sure only one flag is set
checkFlags () {
    if [ $SETUP -eq 1 ] && [ $DISABLE ]; then
        echo "Only one flag can be set" >&2
        echo "Usage: ./patchDarkTheme.sh --setup|--disable|--patch" >&2
        exit 1
    fi
    if [ $SETUP -eq 1 ] && [ $PATCH -eq 1 ]; then
        echo "Only one flag can be set" >&2
        echo "Usage: ./patchDarkTheme.sh --setup|--disable|--patch" >&2
        exit 1
    fi
    if [ $DISABLE -eq 1 ] && [ $PATCH -eq 1 ]; then
        echo "Only one flag can be set" >&2
        echo "Usage: ./patchDarkTheme.sh --setup|--disable|--patch" >&2
        exit 1
    fi
}

# Enable the patch. This will install a cron job and run the patch once.
enablePatch () {

    echo "Enabling patch" >&2
    # Check if the version is patchable
    if ! isPatchableVersion; then
        echo "Insights version is not patchable" >&2
        exit 1
    fi

    installCronJob
    patchInsightsConfigMap

    echo "Patch enabled" >&2
}

# Run the patch once. If the patch is not applicable, remove the cronjob
runPatch () {
    # Check if the version is patchable
    if ! isPatchableVersion; then
        echo "Insights version is not patchable" >&2
        echo "Since patch is not applicable, removing patch (if exists)" >&2
        removePatch
        exit 1
    fi

    patchInsightsConfigMap

    echo "Patch complete" >&2
}

# Remove the patch
removePatch () {

    echo "Removing patch" >&2
    removeCronJob
    argocdEnableSync "insights"
    argocdEnableSync "uipath"
    echo "Patch removed" >&2
    
}


# Using kubect, check argocd for the version of the cluster. We can use kubectl -n argocd get applications -o wide to get hte version fo insights
isPatchableVersion () {
    # Run the kubectl cmd to get the list of applcations. We do this one by one to catch all errors
    kubectlCmd "-n argocd get applications insights -o wide"

    # Get the insights version from CMD_OUT. Its on the second line, 10 column (It gets flattened to one line)
    INSIGHTS_VERSION=$(echo $CMD_OUT |  tail -n 1 | awk '{print $10}')
    if [ -z "$INSIGHTS_VERSION" ]; then
        echo "Failed to get insights version" >&2
        echo "Is Insights installed?" >&2
        exit 1
    fi

    # Specify the allowed versions
    allowed_versions=("2023.4.0" "2023.4.1" "2023.4.2" "2023.4.3")

    # Check if the version is in the list of allowed versions
    found=false
    for allowed_version in "${allowed_versions[@]}"; do
        if [ "$INSIGHTS_VERSION" == "$allowed_version" ]; then
            found=true
            break
        fi
    done

    # Check if version is not in the allowed versions
    if [ "$found" == false ]; then
        echo "Insights version is not between 23.4.0 and 23.4.4" >&2
        return 1
    fi

    return 0
}

# Install the cron job to make sure this is applied on a regular basis. We can adjust the timeing if needed.
installCronJob () {
    # Make sure the cronjob does not exist
    echo "Installing cron job (if it exists)" >&2
    removeCronJob
    
    # Create the cron job. This will run the patchDarkTheme.sh --patch every run every day at midnight. Use the script dir to make sure we have the right path
    local scriptPath=$(realpath $0)
    CRONJOB="0 0 * * * $scriptPath --patch"
    local cmd="echo \"$CRONJOB\" | crontab -"
    execute_command "$cmd"
   
    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Failed to install cron job" >&2
        exit 1
    fi
}

# This will remove the cronjob for when its not needed.
removeCronJob () {
    echo "Removing existing cron job" >&2
    # Remove the cron job
    local cmd="crontab -l | grep -v 'patchDarkTheme.sh --patch' | crontab -"
    execute_command "$cmd"
   
    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Failed to remove cron job" >&2
        exit 1
    fi
}

# Patch the config map. This will allow the dark theme script to execute.
patchInsightsConfigMap () {

    argocdDisableSync "insights"
    argocdDisableSync "uipath"

    # get the config map insightslooker-scripts-cm
    kubectlCmd "-n uipath get configmap insightslooker-scripts-cm -o yaml"

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Failed to get insights config map" >&2
        exit 1
    fi

    # Create a patch file to add the darkTheme key
    local patchFile=$(mktemp)
    echo "Creating patch file $patchFile" >&2
    echo "$CMD_OUT" > $patchFile

    # in the patch file, using sed replace every instance of  curl -k -s -c cookieJar -b cookieJar GET with curl -fksj -c cookieJar -b cookieJar -X GET
    sed -i 's|-k -s -c cookieJar -b cookieJar GET|-fksj -c cookieJar -b cookieJar -X GET|g' $patchFile

    # Apply the patch file
    kubectlCmd "apply -f $patchFile"

    if [ $CMD_EXIT_CODE -ne 0 ]; then
        echo "Failed to patch insights config map" >&2
        exit 1
    fi
}


checkFlags
parseArgs $1
if [ $SETUP -eq 1 ]; then
    enablePatch
elif [ $DISABLE -eq 1 ]; then
    removePatch
elif [ $PATCH -eq 1 ]; then
    runPatch
fi